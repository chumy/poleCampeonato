<?php $__env->startSection('title', 'Carreras'); ?>

<?php $__env->startSection('content'); ?>


<div class="row">

    <div class="col-md-6">
        <div class="card">
            <div class="card-header card-header-primary">
                <h4 class="card-title ">Listado de Carreras</h4>
                <p class="card-category"> Gestión de todas la carreras disponibles</p>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead class=" text-primary">
                            <th>
                                ID
                            </th>
                            <th>
                                Nombre
                            </th>
                            <th>
                            </th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $carreras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($car->id); ?></td>
                                <td><?php echo e($car->nombre); ?></td>

                                <td>
                                    <form action="<?php echo e(action('CarreraController@destroy', $car->id)); ?>" method="post">
                                        <?php echo e(csrf_field()); ?>


                                        <a rel="tooltip" href="<?php echo e(action('CarreraController@edit', $car->id)); ?>"
                                            title="Editar Carrera" class="btn btn-primary btn-link btn-sm">
                                            <i class="material-icons">edit</i>
                                        </a>

                                        <a rel="tooltip" title="<?php echo e(($car->visible) ? 'Visible' : 'No visible'); ?>"
                                            class="btn btn-primary btn-link btn-sm">
                                            <i
                                                class="material-icons"><?php echo e(($car->visible) ? 'visibility' : 'visibility_off'); ?></i>
                                        </a>
                                        <form action="<?php echo e(action('CarreraController@destroy', $car->id)); ?>" method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <input name="_method" type="hidden" value="DELETE">
                                            <button type="submit" rel="tooltip" title="Eliminar Carrera"
                                                class="btn btn-danger btn-link btn-sm">
                                                <i class="material-icons">close</i>
                                            </button>


                                </td>
                                </form>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>

        </div>

    </div>

    <div class="col-md-6">

        <div class="card">
            <div class="card-header card-header-primary">
                <h4 class="card-title">Nueva Carrera</h4>
                <p class="card-category">Rellena informacion de una nueva carrera</p>
            </div>

            <div class="card-body">
                <?php if(isset($carrera)): ?>
                <form method="POST" action="<?php echo e(route('carreras.update',$carrera->id)); ?>" role="form">

                    <input name="_method" type="hidden" value="PATCH">
                    <?php else: ?>
                    <form method="POST" action="<?php echo e(route('carreras.store')); ?>" role="form">
                        <?php endif; ?>

                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label class="bmd-label-floating">Nombre</label>
                                    <input type="text" name="nombre" id="nombre" class="form-control"
                                        value="<?php echo e((isset($carrera->nombre) ? $carrera->nombre : ''  )); ?>">
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="bmd-label-floating">Visible</label>
                                    <div class="form-check">
                                        <label class="form-check-label">
                                            <input class="form-check-input" type="checkbox" name="visible" id="visible"
                                                value=""
                                                <?php echo e((isset($carrera->visible) && ($carrera->visible)) ? 'checked="checked"' : ''); ?>>
                                            <span class="form-check-sign">
                                                <span class="check"></span>
                                            </span>
                                        </label>
                                    </div>
                                </div>
                            </div>

                        </div>


                        <button type="submit" class="btn btn-primary btn-round">
                            <?php echo e((isset($carrera->nombre) ? 'Modificar Carrera': 'Nueva Carrera'  )); ?></button>
                        <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <strong>Error!</strong> Revise los campos obligatorios.<br><br>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/pole/resources/views/admin/carrera.blade.php ENDPATH**/ ?>