<?php $__env->startSection('title', 'Portada'); ?>

<?php $__env->startSection('content'); ?>

<!-- Masthead -->
<header class="masthead text-white text-center pilotos">
    <div class="overlay pilotos"></div>
    <div class="container"></div>
</header>




<section class="secciones-portada bg-light text-center">
    <div class="container">
        <div class="row">
            <div class="col-lg-10">


                <table class="table table-hover table-light">
                    <thead>
                        <tr class="thead-dark">
                            <th scope="col">#</th>
                            <th scope="col">Piloto</th>

                            <th></th>
                        </tr>
                    </thead>
                    <tbody>

                        <tr>
                            <th scope="row">1</th>
                            <td>Apodo 1</td>

                            <td><a href="/pilotos/resultado"><i class="material-icons">timer</i></a></td>

                        </tr>
                        <tr>
                            <th scope="row">2</th>
                            <td>Apodo 2</td>
                            <td><a href="/pilotos/resultado"><i class="material-icons">timer</i></a></td>

                        </tr>



                    </tbody>
                </table>


            </div>


        </div>

    </div>
</section>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/pole/resources/views/pilotos/pilotos.blade.php ENDPATH**/ ?>