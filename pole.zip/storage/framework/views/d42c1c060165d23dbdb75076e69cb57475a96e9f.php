<?php $__env->startSection('title', 'Portada'); ?>

<?php $__env->startSection('content'); ?>

<!-- Masthead -->
<header class="masthead text-white text-center campeonato">
    <div class="overlay campeonato"></div>
    <div class="container"></div>
</header>

<section class="campeonatos lista bg-light">

    <div class="container">
        <div class="row">

            <div class="col-lg-4">

                <nav class="navbar navbar-expand-lg navbar-light bg-light">


                    <span class="navbar-brand mb-0 h1 d-none d-sm-block">Campeonato </span>

                    <div class="navbar" id="navbarSupportedContent">
                        <ul class="navbar-nav mr-auto">


                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <?php echo e($campeonato->nombre); ?>

                                </a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <?php $__currentLoopData = $campeonatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $camplist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a class="dropdown-item"
                                        href="<?php echo e(route('campeonato.show', ['id' => $camplist->id ])); ?>"><?php echo e($camplist->nombre); ?></a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </li>
                        </ul>
                    </div>


            </div>
        </div>
    </div>




</section>


<section class="secciones-portada bg-light text-center">
    <div class="container">
        <div class="row">
            <div class="col-md-8 blog-main">
                <h3 class=" pb-3 mb-4 font-italic border-bottom ">
                    <?php echo e($campeonato->nombre); ?>

                </h3>

                <div class=" blog-post text-left">

                    <p><?php echo e($campeonato->descripcion); ?></p>
                    <hr>

                    <h5>Formato</h5>
                    <dl class="row">
                        <dt class="col-sm-3">Número de coches</dt>
                        <dd class="col-sm-3"><?php echo e($campeonato->coches); ?></dd>
                        <dt class="col-sm-3">Número de carreras</dt>
                        <dd class="col-sm-3"><?php echo e($campeonato->carreras); ?></dd>
                        <dt class="col-sm-3">Vueltas por carreras</dt>
                        <dd class="col-sm-3"><?php echo e($campeonato->vueltas); ?></dd>
                        <dt class="col-sm-3">Penalización por abandono</dt>
                        <dd class="col-sm-3">50%</dd>

                        <dt class="col-sm-3">Pilotos</dt>
                        <dd class="col-sm-3"><?php echo e(($campeonato->pilotos) ? 'Habilitados' : 'Deshabilitados'); ?></dd>
                        <dt class="col-sm-3">Escuderias</dt>
                        <dd class="col-sm-3"><?php echo e(($campeonato->escuderias) ? 'Habilitadas' : 'Deshabilitadas'); ?></dd>

                        <dt class="col-sm-9"></dt>
                        <dd class="col-sm-3"></dd>

                        <dt class="col-sm-3">Puntuación</dt>
                        <dd class="col-sm-9">
                            <?php $__currentLoopData = $campeonato->puntuaciones->puntos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $punto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(!$loop->last): ?>
                            <?php echo e($punto->puntos); ?> -
                            <?php else: ?>
                            <?php echo e($punto->puntos); ?>

                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </dd>

                        <dt class="col-sm-9"></dt>
                        <dd class="col-sm-3"></dd>
                        <?php $__currentLoopData = $carreasEspeciales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carreasEspeciales): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <dt class="col-sm-3">Puntuación especial Carrera <?php echo e($carreasEspeciales->orden); ?></dt>
                        <dd class="col-sm-9">
                            <?php $__currentLoopData = $puntosEspeciales[$loop->index]->puntos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $punto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(!$loop->last): ?>
                            <?php echo e($punto->puntos); ?> -
                            <?php else: ?>
                            <?php echo e($punto->puntos); ?>

                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </dd>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </dl>
                    <hr>

                </div><!-- /.blog-post -->
            </div>
        </div>


</section>

<section class="secciones-portada bg-light text-center">
    <div class="container">
        <div class="row">

            <?php if($campeonato->tipo == 2): ?>
            <div class="col-lg-6">
                <?php else: ?>
                <div class="col-lg-10">
                    <?php endif; ?>

                    <table class="table table-hover table-light">
                        <thead>
                            <tr class="thead-dark">
                                <th scope="col">#</th>
                                <th scope="col">Nombre</th>
                                <?php if($campeonato->pilotos): ?>
                                <th scope="col">Pilotos</th>
                                <?php endif; ?>
                                <?php if($campeonato->escuderias): ?>
                                <th scope="col">Escuderias</th>
                                <?php endif; ?>

                                <th scope="col">Puntuacion</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $clasificacionCampeonato; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clasif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                <td><?php echo e($clasif->apodo); ?></td>
                                <?php if($campeonato->pilotos): ?>
                                <td><?php echo e($clasif->piloto); ?></td>
                                <?php endif; ?>
                                <?php if($campeonato->escuderias): ?>
                                <td><?php echo e($clasif->escuderia); ?></td>
                                <?php endif; ?>
                                <?php if($campeonato->tipo == 2): ?>

                                <td><?php echo e($clasif->puntosTotales); ?>

                                    (<?php echo e($clasif->puntos); ?> + <?php echo e($clasif->puntosEscuderia); ?> ) </td>

                                <?php else: ?>
                                <td><?php echo e($clasif->puntos); ?></td>
                                <?php endif; ?>
                                <td><a
                                        href="<?php echo e(route('campeonato.piloto', [ 'campeonato' =>$campeonato->id ,'participante' => $clasif->id ])); ?>"><i
                                            class="material-icons">timer</i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                        </tbody>
                    </table>


                </div>
                <?php if($campeonato->tipo == 2): ?>
                <div class="col-lg-4">



                    <table class="table table-hover table-light">
                        <thead>
                            <tr class="thead-dark">
                                <th scope="col">#</th>
                                <th scope="col">Escuderia</th>
                                <th scope="col">Posicion</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $clasificacionEscuderias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clasifEsc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                <td><?php echo e($clasifEsc->escuderia); ?></td>
                                <td><?php echo e($clasifEsc->posicion); ?> </td>
                                <td><a href="/campeonato/escuderia/<?php echo e($clasifEsc->id); ?>"><i
                                            class="material-icons">timer</i></a></td>
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>


                </div>
                <?php endif; ?>


            </div>
        </div>
</section>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/pole/resources/views/campeonatos/campeonato.blade.php ENDPATH**/ ?>