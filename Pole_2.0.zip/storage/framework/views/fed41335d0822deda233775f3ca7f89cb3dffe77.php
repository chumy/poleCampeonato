<?php $__env->startSection('title', 'Puntuacion'); ?>

<?php $__env->startSection('content'); ?>


<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-primary">
                <h4 class="card-title">Puntuaciones</h4>
                <p class="card-category">Añadir puntuaciones para los campeonatos</p>
            </div>
            <div class="card-body">
                 <?php if(isset($punto)): ?>
                <form method="POST" action="<?php echo e(route('puntos.update',$punto->id)); ?>" role="form">

                    <input name="_method" type="hidden" value="PATCH">
                    <?php else: ?>
                    <form method="POST" action="<?php echo e(route('puntos.store')); ?>" role="form">
                        <?php endif; ?>

                        <?php echo e(csrf_field()); ?>



                    <div class="row">
                        <div class="col-md-4">

                            <div class="form-group">
                                <label for="exampleSelect2" class="bmd-label-floating">Nombre</label>
                                <input type="text" class="form-control" name="nombre"
                                value="<?php echo e((isset($punto->nombre) ? $punto->nombre : ''  )); ?>">
                            </div>

                        </div>


                        <div class="col-md-4">

                            <div class="form-group">
                                <label for="penalizacion" class="bmd-label-floating">Penalizacion Abandono</label>
                                <select class="form-control" id="penalizacion" name="penalizacion">
                                    <option value="1"
                                    <?php if((isset($punto)) && ($punto->penalizacion == 1) ): ?>
                                    selected
                                    <?php endif; ?>
                                    >Ninguna</option>
                                    <option value="0.5"
                                    <?php if((isset($punto)) && ($punto->penalizacion == 0.5) ): ?>
                                    selected
                                    <?php endif; ?>
                                    >-50%</option>
                                    <option value="0"
                                    <?php if((isset($punto)) && ($punto->penalizacion == 0) ): ?>
                                    selected
                                    <?php endif; ?>
                                    >-100%</option>
                                </select>
                            </div>
                        </div>

                    </div>
  
                    <button type="submit" class="btn btn-primary pull-right">
                        <?php echo e((isset($punto) ? 'Modificar Puntuacion': 'Nueva Puntuacion'  )); ?></button>
                        <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <strong>Error!</strong> Revise los campos obligatorios.<br><br>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
 
   <div class="row">
                        <div class="col-md-2">

                            <div class="form-group">
                                <label for="inputPunt1" class="bmd-label-floating">Primera Posicion</label>
                                <input type="text" class="form-control" name="num1"
                                value="<?php echo e(( isset($punto)  && ( $punto->getPunto(1)->puntos > 0 )  ) ? $punto->getPunto(1)->puntos  : '0'); ?>">
                            </div>

                        </div>
                        <div class="col-md-2">

                            <div class="form-group">
                                <label for="inputPunt2" class="bmd-label-floating">Segunda Posicion</label>
                                <input type="text" class="form-control" name="num2"
                                value="<?php echo e(( isset($punto)  && ( $punto->getPunto(2)->puntos > 0 )  ) ? $punto->getPunto(2)->puntos  : '0'); ?>">
                            </div>
                        </div>

                        <div class="col-md-2">

                            <div class="form-group">
                                <label for="inputPunt3" class="bmd-label-floating">Tercera Posicion</label>
                                <input type="text" class="form-control" name="num3"
                                value="<?php echo e(( isset($punto)  && ( $punto->getPunto(3)->puntos > 0 )  ) ? $punto->getPunto(3)->puntos  : '0'); ?>">
                            </div>

                        </div>
                        <div class="col-md-2">

                            <div class="form-group">
                                <label for="inputPunt4" class="bmd-label-floating">Cuarta Posicion</label>
                                <input type="text" class="form-control" name="num4"
                                value="<?php echo e(( isset($punto)  && ( $punto->getPunto(4)->puntos > 0 )  ) ? $punto->getPunto(4)->puntos  : '0'); ?>">
                            </div>

                        </div>

                        <div class="col-md-2">

                            <div class="form-group">
                                <label for="inputPunt5" class="bmd-label-floating">Quinta Posicion</label>
                                <input type="text" class="form-control"  name="num5"
                                value="<?php echo e(( isset($punto)  && ( $punto->getPunto(5)->puntos > 0 )  ) ? $punto->getPunto(5)->puntos  : '0'); ?>">
                            </div>
                        </div>

                        <div class="col-md-2">

                            <div class="form-group">
                                <label for="inputPunt6" class="bmd-label-floating">Sexta Posicion</label>
                                <input type="text" class="form-control" name="num6"
                                value="<?php echo e(( isset($punto)  && ( $punto->getPunto(6)->puntos > 0 )  ) ? $punto->getPunto(6)->puntos  : '0'); ?>">
                            </div>

                        </div>
                        

                    </div>


                </form>
            </div>
        </div>
    </div>

</diV>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-primary">
                <h4 class="card-title ">Listado de Puntuaciones</h4>
                <p class="card-category"> Gestión de las puntuaciones disponibles para el campeonato</p>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead class=" text-primary">
                            <th>
                                ID
                            </th>
                            <th>
                                Nombre
                            </th>
                            <th>
                                Abandono
                            </th>
                            <th>Puntuacion</th>

                            <th>
                            </th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $puntos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $punt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($punt->id); ?>

                                </td>
                                <td>
                                    <?php echo e($punt->nombre); ?>

                                </td>
                                <td>
                                     <?php if($punt->penalizacion == 1): ?> 
                                     Ninguna
                                     <?php else: ?> 
                                     <?php echo e(($punt->penalizacion * 100) -100); ?> %
                                     <?php endif; ?> 
                                </td>
                                <td><?php echo e($punt->toText()); ?></td>

                                <td>

                                    <form action="<?php echo e(action('PuntoController@destroy', $punt->id)); ?>" method="post">
                                      <a rel="tooltip" href="<?php echo e(action('PuntoController@edit', $punt->id)); ?>"
                                        title="Editar Puntuación" class="btn btn-primary btn-link btn-sm">
                                        <i class="material-icons">edit</i>
                                    </a>

                                     <a rel="tooltip" title="<?php echo e(($punt->visible) ? 'Visible' : 'No visible'); ?>"
                                        class="btn btn-primary btn-link btn-sm">
                                        <i
                                            class="material-icons"><?php echo e(($punt->visible) ? 'visibility' : 'visibility_off'); ?></i>
                                    </a>

                                       <?php echo e(csrf_field()); ?>

                                        <input name="_method" type="hidden" value="DELETE">
                                        <!--button type="submit" rel="tooltip" title="Eliminar Puntuación"
                                            class="btn btn-danger btn-link btn-sm" data-toggle="modal" data-target="#exampleModal">
                                            <i class="material-icons">close</i>
                                        </button-->
                                        <a rel="tooltip" href="javascript:delWarning(<?php echo e($punt->id); ?>)"
                                        title="Editar Puntuación" class="btn btn-danger btn-link btn-sm">
                                        <i class="material-icons">close</i>
                                    </a>
                                    </form>


                                </td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>

</diV>



<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Eliminar Puntuación</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Eliminar puntuaciones puede repecutir en la puntuacion de los campeonatos que tengan relacionada esta puntuación. Asegurese de que esta puntuación no se está utilizando en ningun campeonato/carrera antes de eliminarla.
      </div>
      <form id="modalFormDelete" method="post">
        <?php echo e(csrf_field()); ?>

                                        <input name="_method" type="hidden" value="DELETE">
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
        <button type="submitn" class="btn btn-primary">Eliminar puntuacion</button>

      </div>
      </form>
    </div>
  </div>
</div>


<script type="text/javascript">
function delWarning(id){

    $('#exampleModalLabel').html("Eliminar Puntuación");
    $('#exampleModal').modal('toggle');
    $('#modalFormDelete').attr('action','/admin/puntos/'+id);
    
};

</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/pole/resources/views/admin/puntuacion.blade.php ENDPATH**/ ?>