<?php $__env->startSection('title', 'Resultados'); ?>

<?php $__env->startSection('content'); ?>


<?php if(isset($campeonato->nombre) ): ?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-primary">

                <div class="btn-group">

                    <div class="dropdown show">
                        <a class="btn btn-primary dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <?php echo e($campeonato->nombre); ?>

                        </a>

                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                            <?php $__currentLoopData = $campeonatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $camp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="dropdown-item"
                                href="<?php echo e(route('resultados.show', [ 'campeonato' =>$camp->id ])); ?>"><?php echo e($camp->nombre); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>


                    <div class="dropdown show">
                        <a class="btn btn-primary dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <?php echo e($carrera->circuito->nombre); ?>

                        </a>

                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                            <?php $__currentLoopData = $campeonato->carreras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="dropdown-item"
                                href="<?php echo e(route('resultados.show', [ 'campeonato' =>$campeonato->id , 'carrera' => $car->id, ])); ?>"><?php echo e($car->circuito->nombre); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>

                </div>



                <p class="card-category"> Organiza el resultado de la carrera</p>
            </div>
            <div class="card-body">
                <div class="">


                    <table class="table">
                        <thead class=" text-primary">
                            <th>
                                ID
                            </th>
                            <th>
                                Nombre
                            </th>
                            <th>
                                Coche
                            </th>
                            <?php if($campeonato->pilotos): ?>
                            <th>Piloto</th>
                            <?php endif; ?>
                            <?php if($campeonato->escuderias || $campeonato->tipo == 2): ?>
                            <th>Escuderia</th>
                            <?php endif; ?>
                            <th>Participacion</th>
                            <th>Abandono</th>
                            <th>
                            </th>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $carrera->getResultado(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($pos->posicion); ?>

                                </td>
                                <td>
                                    <?php echo e($pos->participante()->apodo); ?>

                                </td>
                                <td>
                                    
                                    <?php echo e($pos->inscrito->coche->nombre); ?>

                                    
                                </td>
                                <?php if($campeonato->pilotos): ?>
                                <td>
                                    <?php if($pos->inscrito->piloto): ?>
                                    <?php echo e($pos->inscrito->piloto->nombre); ?>

                                    <?php endif; ?>
                                </td>
                                <?php endif; ?>
                                 <?php if($campeonato->escuderias || $campeonato->tipo == 2): ?>
                                <td>
                                    <?php if($pos->inscrito->escuderia): ?>
                                    <?php echo e($pos->inscrito->escuderia->nombre); ?>

                                    <?php endif; ?>
                                </td>
                                <?php endif; ?>
                                <td>

                                    <form
                                        action="<?php echo e(route('resultados.participacion',  [ 'campeonato' =>$campeonato->id , 'carrera' => $carrera->id, 'resultado' => $pos->id , ] )); ?>"
                                        method="post">
                                        <?php echo e(csrf_field()); ?>

                                        <input name="_method" type="hidden" value="PATCH">
                                        <div class="form-check">
                                            <label class="form-check-label">
                                                <input class="form-check-input" type="checkbox"
                                                    onClick="this.form.submit()" name="participacion"
                                                    value="<?php echo e($pos->participacion); ?>" <?php if($pos->participacion): ?>
                                                checked
                                                <?php endif; ?>
                                                >
                                                <span class="form-check-sign">
                                                    <span class="check"></span>
                                                </span>
                                            </label>
                                        </div>
                                    </form>
                                </td>
                                <td>
                                    <form
                                        action="<?php echo e(route('resultados.abandono',  [ 'campeonato' =>$campeonato->id , 'carrera' => $carrera->id, 'resultado' => $pos->id , ] )); ?>"
                                        method="post">
                                        <?php echo e(csrf_field()); ?>

                                        <input name="_method" type="hidden" value="PATCH">
                                        <div class="form-check">
                                            <label class="form-check-label">
                                                <input class="form-check-input" type="checkbox" name="abandono"
                                                    onClick="this.form.submit()" value="<?php echo e($pos->abandono); ?>"
                                                    <?php if($pos->abandono): ?>
                                                checked
                                                <?php endif; ?>
                                                >
                                                <span class="form-check-sign">
                                                    <span class="check"></span>
                                                </span>
                                            </label>
                                        </div>
                                    </form>
                                </td>
                                <td>
                                    <div class="row">
                                        <form
                                            action="<?php echo e(route('resultados.up',  [ 'campeonato' =>$campeonato->id , 'carrera' => $carrera->id, 'resultado' => $pos->id , ] )); ?>"
                                            method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <input name="_method" type="hidden" value="PATCH">
                                            <button type="submit" rel="tooltip" title="Subir Posicion"
                                                class="btn btn-primary btn-link btn-sm">
                                                <i class="material-icons">arrow_upward</i>
                                            </button>
                                        </form>
                                        <form
                                            action="<?php echo e(route('resultados.down',  [ 'campeonato' =>$campeonato->id , 'carrera' => $carrera->id, 'resultado' => $pos->id , ] )); ?>"
                                            method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <input name="_method" type="hidden" value="PATCH">
                                            <button type="submit" rel="tooltip" title="Bajar Posicion"
                                                class="btn btn-primary btn-link btn-sm">
                                                <i class="material-icons">arrow_downward</i>
                                            </button>
                                        </form>
                                     </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>

            
            
        </div>
        <form
             action="<?php echo e(route('resultados.publicar',  [  'campeonato' =>$campeonato->id , 'carrera' => $carrera->id] )); ?>"
              method="post">
            <?php echo e(csrf_field()); ?>

            <input name="_method" type="hidden" value="PATCH">
        <button type="submit" class="btn btn-primary btn-round">
           <?php if($carrera->visible == 1): ?>
            Ocultar Resultado
            <?php else: ?>
            Publicar Resultado
            <?php endif; ?>
        </button>
        </form>
    </div>
</div>
<?php else: ?>
<div class="row">
    <div class="col-md-12">No hay Campeonatos creados</div>
</div>

<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/pole/resources/views/admin/resultado.blade.php ENDPATH**/ ?>