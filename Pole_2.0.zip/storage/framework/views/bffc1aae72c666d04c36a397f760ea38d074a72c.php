<?php $__env->startSection('content'); ?>

<!-- Clasificacion -->


                        

<section class="secciones-portada text-center">
    <div class="container">
        <div class="row">

            <?php if($campeonato->tipo == 2): ?>
                <div class="col-lg-8">
            <?php else: ?>
                <div class="col-lg-10">
            <?php endif; ?>

                    <table class="table table-hover ">
                        <thead>
                            <tr class="thead-dark">
                                <th scope="col">#</th>
                                <th scope="col">Coche</th>
                                <th scope="col">Nombre</th>
                                <th></th>
                                <?php if($campeonato->pilotos): ?>
                                <th scope="col">Pilotos</th>
                                <?php endif; ?>
                                <?php if($campeonato->escuderias): ?>
                                <th scope="col">Escuderias</th>
                                <?php endif; ?>

                                <th scope="col">Puntuacion</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if( $campeonato->getClasificacion()->count() > 0): ?> 
                           
                            <?php $__currentLoopData = $campeonato->getClasificacion(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clasif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row" rowspan="<?php echo e($clasif->inscritos->count()); ?>"><?php echo e($loop->iteration); ?></th>
                                <td rowspan="<?php echo e($clasif->inscritos->count()); ?>" ><?php echo e($clasif->coche->nombre); ?></td>
                                <?php $__currentLoopData = $clasif->inscritos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conductor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if( $loop->iteration > 1): ?>
                                        <tr>
                                    <?php endif; ?>

                                    
                                    <td ><?php echo e($conductor->participante->apodo); ?></td>
                                    
                                    <?php if($campeonato->pilotos): ?>
                                    <td><?php echo e($conductor->piloto->nombre); ?></td>
                                    <?php endif; ?>
                                <td>
                                    <?php if($clasif->inscritos->count() > 1): ?>
                                <a
                                        href="<?php echo e(route('campeonato.piloto', [ 'campeonato' =>$campeonato->slug ,'participante' => $conductor->participante->id])); ?>"><i
                                            class="material-icons">timer</i></a>

                                            
                                
                                <?php endif; ?>
                                </td>
                                <?php if( $loop->iteration == 1): ?>
                                    <?php if($campeonato->escuderias): ?>
                                    <td rowspan="<?php echo e($clasif->inscritos->count()); ?>"><?php echo e($conductor->escuderia->nombre); ?></td>
                                    <?php endif; ?>

                                <td  rowspan="<?php echo e($clasif->inscritos->count()); ?>"><?php echo e($clasif->puntos); ?>

                                <?php if($campeonato->tipo == 2 || $campeonato->tipo == 3  ): ?>
                                    (<?php echo e($clasif->puntos_pilotos); ?>+<?php echo e($clasif->puntos_esc); ?>) 

                                <?php endif; ?>
                                </td>
                                <td rowspan="<?php echo e($clasif->inscritos->count()); ?>"><a
                                        href="<?php echo e(route('campeonato.coche', [ 'campeonato' =>$campeonato->slug ,'coche' => $conductor->coche])); ?>"><i
                                            class="material-icons">timer</i></a>
                                </td>
                                <?php endif; ?>
                                <?php if( $loop->iteration > 1): ?>
                            </tr>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                        </tbody>
                    </table>


                </div>
                <?php if($campeonato->tipo == 2): ?>
                <div class="col-lg-4">



                    <table class="table table-hover">
                        <thead>
                            <tr class="thead-dark">
                                <th scope="col">#</th>
                                <th scope="col">Escuderia</th>
                                <th scope="col">Puntuacion</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($campeonato->getClasificacionEscuderias()->count() > 0): ?>
                            <?php $__currentLoopData = $campeonato->getClasificacionEscuderias(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clasifEsc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                <td><?php echo e($clasifEsc->escuderia->nombre); ?></td>
                                <td><?php echo e($clasifEsc->puntos); ?> (<?php echo e($clasifEsc->puntos_escuderia); ?>) </td>
                                <td><a
                                        href="<?php echo e(route('campeonato.escuderia', [ 'campeonato' =>$campeonato->slug ,'escuderia' => $clasifEsc->escuderia->id  ])); ?>"><i
                                            class="material-icons">timer</i></a></td>
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>


                </div>
                <?php endif; ?>


            </div>
        </div>
</section>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/pole/resources/views/campeonatos/clasificacion.blade.php ENDPATH**/ ?>