<?php $__env->startSection('title', 'Campeonatos'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
          <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title ">Listado de Participantes</h4>
                  <p class="card-category"> Gestión de todos los participantes disponibles para el campeonato</p>
                </div>
                <div class="card-body">
                  <div class="">
                    <table class="table">
                      <thead class=" text-primary">
                        <th>
                          ID
                        </th>
                        <th>
                          Nombre
                        </th>
                        <th>
                          Coche
                        </th>
                        <?php if($campeonato->pilotos): ?>
                        <th>Piloto</th>
                        <?php endif; ?>
                        <?php if($campeonato->escuderias || ($campeonato->tipo == 2)  ): ?>
                        <th>Escuderia</th>
                        <?php endif; ?>
                        <th>
                        </th>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $campeonato->inscritos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ins): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td>
                            <?php echo e($loop->iteration); ?>

                          </td>
                          <td>
                            <?php echo e($ins->participante->apodo); ?>

                          </td>
                          <td>
                            <?php echo e(($ins->coche) ? $ins->coche->nombre : ''); ?>

                          </td>
                          <?php if($campeonato->pilotos): ?>
                          <td><?php echo e(($ins->piloto) ? $ins->piloto->nombre : ''); ?></td>
                          
                          <?php endif; ?>

                          <?php if($campeonato->escuderias  || ($campeonato->tipo == 2) ): ?>
                          <td><?php echo e(($ins->escuderia) ? $ins->escuderia->nombre : ''); ?></td>
                          
                          <?php endif; ?>
<td>
    <div class="row">
   <a rel="tooltip" href="<?php echo e(action('InscritoController@edit', $ins->id)); ?>" 
                                        title="Editar Inscripcion"
                                        class="btn btn-primary btn-link btn-sm">
                                        <i class="material-icons">edit</i>
                                </a>

  <form action="<?php echo e(action('InscritoController@destroy', $ins->id)); ?>" method="post">
                                        <?php echo e(csrf_field()); ?>

                                        <input name="_method" type="hidden" value="DELETE">
                                        <button type="submit" rel="tooltip" title="Eliminar Inscripción"
                                            class="btn btn-danger btn-link btn-sm">
                                            <i class="material-icons">close</i>
                                        </button>
                                    </form>
                          </div>
                          </td>
                          
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                      </tbody>
                    </table>
                  </div>
                </div>

              </div>
            </div>
            </div>

            </diV>


<div class="row">
          <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                <h4 class="card-title"><?php echo e($campeonato->nombre); ?></h4>
                  <p class="card-category">Añadir Participantes al campeonato</p>
                </div>
                <div class="card-body">
                  <?php if(isset($inscrito)): ?>
                    <form method="POST" action="<?php echo e(route('inscritos.update',['inscrito' => $inscrito->id])); ?>" role="form">
                    <input name="_method" type="hidden" value="PATCH">
                <?php else: ?>
                    <form method="POST" action="<?php echo e(route('inscritos.store')); ?>" role="form">
                <?php endif; ?>
                        <?php echo e(csrf_field()); ?>

                      <input type="hidden" name='campeonato_id' value="<?php echo e($campeonato->id); ?>">
                   
                
                    <div class="row">
                      

                      <div class="col-md-3">
                        
                        <div class="form-group">
                          <label for="coche_id" class="bmd-label-floating">Coche</label>
                          <select class="form-control" id="coche_id" name="coche_id">
                            <?php if( isset($inscrito) ): ?>
                              <option value="<?php echo e($inscrito->coche->id); ?>" selected><?php echo e($inscrito->coche->nombre); ?></option>
                            <?php endif; ?>
                             <?php $__currentLoopData = $coches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>             
                            <option value="<?php echo e($car->id); ?>"><?php echo e($car->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>

                      </div>

                      <div class="col-md-3">
                        
                        <div class="form-group">
                          <label for="participante_id" class="bmd-label-floating">Participante</label>
                          <select class="form-control" id="participante_id" name="participante_id">
                            <?php if( isset($inscrito) ): ?>
                              <option value="<?php echo e($inscrito->participante->id); ?>" selected><?php echo e($inscrito->participante->apodo); ?></option>
                            <?php endif; ?>
                             <?php $__currentLoopData = $participantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $par): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>             
                            <option value="<?php echo e($par->id); ?>"><?php echo e($par->apodo); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>

                      </div>

                      <?php if($campeonato->pilotos): ?>
                     
                      <div class="col-md-3">
                        
                        <div class="form-group">
                          <label for="piloto_id" class="bmd-label-floating">Piloto</label>
                          <select class="form-control" id="piloto_id" name="piloto_id">
                             <?php $__currentLoopData = $pilotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($pil->id); ?>"
                              <?php if( (isset($inscrito->piloto->id)) && ($inscrito->piloto->id == $pil->id) ): ?>
                               selected
                               <?php endif; ?>
                              ><?php echo e($pil->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>

                      </div>
                      <?php endif; ?>

                      <?php if($campeonato->escuderias || ($campeonato->tipo == 2) ): ?>
                      <div class="col-md-3">
                        
                        <div class="form-group">
                          <label for="escuderia_id" class="bmd-label-floating">Escuderia</label>
                          <select class="form-control" id="escuderia_id" name="escuderia_id">
                            <?php $__currentLoopData = $escuderias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $esc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($esc->id); ?>"
                              <?php if( (isset($inscrito->escuderia->id)) && ($inscrito->escuderia->id == $esc->id) ): ?>
                               selected
                               <?php endif; ?>
                              ><?php echo e($esc->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>

                      </div>
                      <?php endif; ?>

                    </div>
                      
                    

                    <button type="submit" class="btn btn-primary pull-right"><?php echo e((isset($inscrito) ? 'Modificar Participante': 'Añadir Participante'  )); ?></button>
                    <div class="clearfix"></div>
                    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <strong>Error!</strong> Revise los campos obligatorios.<br><br>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                    
                 
                  </form>
                </div>
              </div>
          </div>     
</diV>
          
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/pole/resources/views/admin/inscrito.blade.php ENDPATH**/ ?>