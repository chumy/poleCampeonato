<?php $__env->startSection('title', 'Pilotos'); ?>

<?php $__env->startSection('content'); ?>
 
 

          <div class="row">
              

            <div class="col-md-6">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title ">Listado de Pilotos</h4>
                  <p class="card-category"> Gestión de todas la carreras disponibles</p>
                </div>
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table">
                      <thead class=" text-primary">
                        <th>
                          ID
                        </th>
                        <th>
                          Nombre
                        </th>
                        <th>
                        </th>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $pilotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($pil->nombre); ?></td>

                                <td>
                                  <form action="<?php echo e(action('PilotoController@destroy', $pil->id)); ?>" method="post">
                                    <a rel="tooltip" href="<?php echo e(action('PilotoController@edit', $pil->id)); ?>"
                                        title="Editar Circuito" class="btn btn-primary btn-link btn-sm">
                                        <i class="material-icons">edit</i>
                                    </a>

                                    <a rel="tooltip" title="<?php echo e(($pil->visible) ? 'Visible' : 'No visible'); ?>"
                                        class="btn btn-primary btn-link btn-sm">
                                        <i
                                            class="material-icons"><?php echo e(($pil->visible) ? 'visibility' : 'visibility_off'); ?></i>
                                    </a>
                                    
                                        <?php echo e(csrf_field()); ?>

                                        <input name="_method" type="hidden" value="DELETE">
                                        <button type="submit" rel="tooltip" title="Eliminar Carrera"
                                            class="btn btn-danger btn-link btn-sm">
                                            <i class="material-icons">close</i>
                                        </button>
                                    </form>

                                </td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>

              </div>

            </div>

            <div class="col-md-6">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Nuevo Piloto</h4>
                  <p class="card-category">Rellena informacion de un nuevo piloto</p>
                </div>
                <div class="card-body">
                   <?php if(isset($piloto)): ?>
                <form method="POST" action="<?php echo e(route('pilotos.update',$piloto->id)); ?>" role="form">

                    <input name="_method" type="hidden" value="PATCH">
                    <?php else: ?>
                    <form method="POST" action="<?php echo e(route('pilotos.store')); ?>" role="form">
                        <?php endif; ?>

                        <?php echo e(csrf_field()); ?>

                    <div class="row">
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label class="bmd-label-floating">Nombre</label>
                                    <input type="text" name="nombre" id="nombre" class="form-control"
                                        value="<?php echo e((isset($piloto->nombre) ? $piloto->nombre : ''  )); ?>">
                                </div>
                            </div>

                           

                        
                        <div class="col-md-4">
                                <div class="form-group">
                                    <label class="bmd-label-floating">Visible</label>
                                    <div class="form-check">
                                        <label class="form-check-label">
                                            <input class="form-check-input" type="checkbox" name="visible" id="visible"
                                                value="<?php echo e((isset($piloto->visible) ? $piloto->visible : '0'  )); ?>"
                                                <?php echo e((isset($piloto->visible) && ($piloto->visible)) ? 'checked="checked"' : ''); ?>>

                                            <span class="form-check-sign">
                                                <span class="check"></span>
                                            </span>
                                        </label>
                                    </div>
                                </div>
                            </div>

                    </div>
                    
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <label>Caracteristicas</label>
                          <div class="form-group">
                            <label class="bmd-label-floating"> Descripcion de las habilidades especificas del piloto.</label>
                            <textarea class="form-control" rows="5" name="descripcion"><?php echo e((isset($piloto->descripcion) ? $piloto->descripcion : ''  )); ?></textarea>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                        <button type="submit" class="btn btn-primary btn-round">
                            <?php echo e((isset($piloto) ? 'Modificar Piloto': 'Nuevo Piloto'  )); ?></button>
                        <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <strong>Error!</strong> Revise los campos obligatorios.<br><br>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                  </form>
                </div>
              </div>
            </div>

          
        
 
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/pole/resources/views/admin/piloto.blade.php ENDPATH**/ ?>