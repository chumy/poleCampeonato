<?php $__env->startSection('content'); ?>


<section class=" text-center">

    <div class="container ">
        <div class="row">
            <div class="col-md-12 blog-main bg-light">

                <h3 class=" pb-3 mb-4 font-italic border-bottom ">
                    <?php echo e($campeonato->nombre); ?>

                </h3>

                <div class=" blog-post text-left">

                    <p><?php echo e($campeonato->descripcion); ?></p>
                    <hr>

                    <h5>Formato</h5>
                    <dl class="row">
                        <dt class="col-sm-3">Número de coches</dt>
                        <dd class="col-sm-3"><?php echo e($campeonato->num_coches); ?></dd>
                        <dt class="col-sm-3">Número de carreras</dt>
                        <dd class="col-sm-3"><?php echo e($campeonato->num_carreras); ?></dd>
                        <dt class="col-sm-3">Vueltas por carreras</dt>
                        <dd class="col-sm-3"><?php echo e($campeonato->num_vueltas); ?></dd>
                        <dt class="col-sm-3">Penalización por abandono</dt>
                        <dd class="col-sm-3">50%</dd>

                        <dt class="col-sm-3">Pilotos</dt>
                        <dd class="col-sm-3"><?php echo e(($campeonato->pilotos) ? 'Habilitados' : 'Deshabilitados'); ?></dd>
                        <dt class="col-sm-3">Escuderias</dt>
                        <dd class="col-sm-3"><?php echo e(($campeonato->escuderias) ? 'Habilitadas' : 'Deshabilitadas'); ?></dd>

                        <dt class="col-sm-9"></dt>
                        <dd class="col-sm-3"></dd>
                        
                        <dt class="col-sm-3">Puntuación</dt>
                        <dd
                        <?php if($campeonato->puntuaciones->toText()): ?>
                        class="col-sm-3"
                        <?php else: ?>
                        class="col-sm-9"
                        <?php endif; ?>  
                        >
                           <?php echo e($campeonato->puntuaciones->toText()); ?>


                        </dd>
                         <?php if($campeonato->getPuntuacionesEscuderias): ?>
                         <dt class="col-sm-3">Puntuación de Escuderías</dt>
                        <dd class="col-sm-3"><?php echo e($campeonato->getPuntuacionesEscuderias->toText()); ?>

                         <?php endif; ?>
                        <dt class="col-sm-9"></dt>
                        <dd class="col-sm-3"></dd>
                        <?php $__currentLoopData = $campeonato->getPuntuacionesCarreras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carreasEspeciales): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <dt class="col-sm-3">Puntuación especial Carrera <?php echo e($carreasEspeciales->orden); ?></dt>
                        <dd class="col-sm-9"><?php echo e($carreasEspeciales->puntos->toText()); ?></dd>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </dl>
                    <hr>

                </div><!-- /.blog-post -->
            </div>
        </div> <!-- row -->
    </div>
    
<div class="gap-up" ></div>
<div class="container">
 
    <div class="row justify-content-md-center " >

      <div class="col col-sm-3 "> <!-- Campeonato-->
        <a href="<?php echo e(route ('campeonato.clasificacion',['slug' => $campeonato->slug])); ?>" class="secciones-enlace">
            <div class="card" >
                <img class="card-img-top" src="<?php echo e(asset ('images/campeonato1_960.jpg')); ?>" alt="Card image cap">
                <div class="card-body  bg-light">

                    <h3>Clasificacion</h3>
            

                </div>
            </div>
        </a>
      </div>

      <div class="col col-sm-3 "> <!-- Calendario-->
        <a href="<?php echo e(route ('campeonato.calendario',['slug' => $campeonato->slug])); ?>" class="secciones-enlace">
            <div class="card" >
                <img class="card-img-top" src="<?php echo e(asset ('images/calendario960.jpg')); ?>"" alt="Card image cap">
                <div class="card-body  bg-light">

                    <h3>Calendario</h3>
            

                </div>
            </div>
        </a>
      </div>

      <!-- Pilotos -->
      <div class="col-sm-3"> 
        <a href="<?php echo e(route ('campeonato.pilotos',['slug' => $campeonato->slug])); ?>" class="secciones-enlace">
            <div class="card" >
                <img class="card-img-top" src="<?php echo e(asset ('images/pilotos960smooth.jpg')); ?>"" alt="Card image cap">
                <div class="card-body  bg-light">

                    <h3>Pilotos</h3>
                    

                </div>
            </div>
        </a>
      </div>

    <!-- Escuderias-->  
     <?php if($campeonato->escuderias || ($campeonato->tipo== 2)): ?>
        <div class="col col-sm-3">
           
            <a href="<?php echo e(route ('campeonato.escuderias',['slug' => $campeonato->slug])); ?>" class="secciones-enlace">
                <div class="card" >
                    <img class="card-img-top" src="<?php echo e(asset ('images/escuderias960smooth.jpg')); ?>" alt="Card image cap">
                    <div class="card-body  bg-light">

                        <h3>Escuderias</h3>
                      

                    </div>
                </div>
            </a>
        </div>

      <?php endif; ?>
    </div>


</section>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/pole/resources/views/campeonatos/descripcion.blade.php ENDPATH**/ ?>