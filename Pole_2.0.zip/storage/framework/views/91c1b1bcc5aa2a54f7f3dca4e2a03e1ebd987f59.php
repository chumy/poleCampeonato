<?php $__env->startSection('title', 'Portada'); ?>

<?php $__env->startSection('content'); ?>



<section class="campeonatos lista">

    <div class="container">
        <div class="row">

            

            <div class="col-sm-2"></div>
            <div class="col-sm-8">

                <div class="card flex-row  card-escuderia">
                    <div class="card-header border-0 ">
                       <img class="image-desc img-thumbnail card-escuderia-image"
                             src=" <?php echo e(($coche->imagen) ? $coche->imagen : asset('images/person_8x10.png')); ?>" alt="" >
                    </div>
                    
                    <div class="card-block px-2">
                        <h4 class="card-title"><?php echo e($coche->nombre); ?></h4>
                        <?php $__currentLoopData = $campeonato->inscritos->where('coche_id', $coche->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inscrito): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p class="card-title">Piloto: <?php echo e($inscrito->participante->nombre); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($inscrito->escuderia): ?>
                            <p class="card-title">Escuderia: <?php echo e($inscrito->escuderia->nombre); ?></p>
                            <?php endif; ?>
                            <?php if($inscrito->piloto): ?>
                            <p class="card-title">Piloto: <?php echo e($inscrito->piloto->nombre); ?></p>
                            <?php endif; ?>
                    </div>
                    
                </div>

            </div>
            <div class="col-sm-2"></div>
        </div> 

        </div>
    </div>




</section>


<section class="secciones-portada text-center">
    <div class="container">
        <div class="row">
            <div class="col-sm-1"></div>
            <div class="col-sm-10">


                <table class="table table-hover">
                    <thead>
                        <tr class="thead-dark">
                            <th scope="col">#</th>
                            <th scope="col">Carrera</th>
                            <th scope="col">Posicion</th>
                            <th scope="col">Puntuacion</th>

                        </tr>
                    </thead>
                    <tbody>

                        <?php $__currentLoopData = $clasificacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carrera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td><?php echo e($carrera->carrera->circuito->nombre); ?></td>
                            <td><?php echo e($carrera->posicion); ?></td>
                            <td><?php echo e($carrera->puntos()); ?></td>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                    </tbody>
                </table>

                <div class="text-right">
                    <h3> <span class="badge badge-secondary">Total: <?php echo e($clasificacion->sum(function($value){ return $value->puntos(); })); ?> puntos</span>
                    </h3>
                </div>

            </div>


        </div>
<div class="col-sm-1"></div>
    </div>
</section>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/pole/resources/views/campeonatos/coche.blade.php ENDPATH**/ ?>