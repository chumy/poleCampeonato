<?php $__env->startSection('title', 'Portada'); ?>

<?php $__env->startSection('content'); ?>

<div class="container" style="height: 80%">
 
    <div class="row justify-content-md-center " style="height: 100%">
      <div class="col col-sm-4" style="height: 30%"> <!-- Campeonato-->
 <?php if($campeonatos->count() > 0): ?>
        <div class="card " style=" background: transparent">
            <div class="card-body card-f1-title">
                <h5 class="card-title">Campeonatos</h5>
                <!--img class="card-img-top" src="./Pole Position_files/campeonato2.jpg" alt="Card image"-->
            </div>
            <ul class="list-group list-group-flush list-f1">
                <?php $__currentLoopData = $campeonatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $camp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item">
                    <a class="list-f1" href="<?php echo e(route ('campeonato.show', ['campeonato'=>$camp->slug])); ?>"><?php echo e($camp->nombre); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
        </div>
        <?php endif; ?>
      </div>
      <div class="col-sm-3"> <!-- Separacion -->

      </div>
 <!-- Carreras-->  
     
<div class="col col-sm-5">
    <!-- Gap -->
    <?php if($carreras->count() > 0): ?>
    <div class="row" style="height: 60%;" ></div>
    <div class="card"  style="  background: transparent">
      <div class="card-body  card-f1-title">
          <h5 class="card-title">Proximas Carreras</h5>
      </div>
      <ul class="list-group list-group-flush list-f1" >
          <?php $__currentLoopData = $carreras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="list-group-item ">
              <a class="list-f1" href="<?php echo e(route ('campeonato.calendario', ['campeonato'=>$car->campeonato->slug, 'carrera' => $car->id])); ?>"><?php echo e($car->fecha); ?> - <?php echo e($car->circuito->nombre); ?></a></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         
        </ul>
  </div>
  <?php endif; ?>
</div>

      
    </div>
   
    
</div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/pole/resources/views/welcome.blade.php ENDPATH**/ ?>