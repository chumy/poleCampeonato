<?php $__env->startSection('title', 'Calendario'); ?>

<?php $__env->startSection('content'); ?>


<section class="text-center">

    <div class="container">
        <div class="row">

            

            <div class="col-sm-3"></div>
            <div class="col-sm-6 grad" >

                <div class="card flex-row  card-calendario ">
                    
                   <div class="card-block px-2  text-center col-sm-3">
                       <?php if($previous): ?>
                        <a  class="card-direction" href="<?php echo e(Route('campeonato.calendario', ['campeonato'=>$campeonato->slug , 'carrera'=>$previous->id])); ?>">
                         <i class="material-icons card-direction ">navigate_before</i></a>
                        <?php endif; ?>
                    </div>
                    
                    
                    <div class="card-block px-2 text-center col-sm-6">
                        <h4 class="card-title "><?php echo e($carrera->fecha); ?> <?php echo e($carrera->circuito->nombre); ?></h4>
                    </div>
                    
                     <div class="card-block text-center align-middle px-2 col-sm-3">
                         <?php if($next): ?>
                        <a class="card-direction" href="<?php echo e(Route('campeonato.calendario', ['campeonato'=>$campeonato->slug , 'carrera'=>$next->id])); ?>">
                        <i class="material-icons card-direction ">navigate_next</i></a>
                        <?php endif; ?>
                    </div>
                    
                    
                </div>
            </div>
            <div class="col-sm-3"></div>
        </div> 

    </div>


</section>



<section class="secciones-portada  text-center">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">


                <table class="table table-hover ">
                    <thead>
                        <tr class="thead-dark">
                            <th scope="col">#</th>
                            <th scope="col">Coche</th>
                            <th scope="col">Piloto</th>
                            <?php if($carrera->visible == 1 ): ?>
                            <th scope="col">Puntos</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $carrera->resultados->where('participacion',1)->sortby('posicion'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                        <td><?php echo e($clas->inscrito->coche->nombre); ?></td>
                        <td><?php echo e($clas->inscrito->participante->apodo); ?></td>
                         <?php if($carrera->visible == 1 ): ?>
                            <td><?php echo e($clas->puntos()); ?></td>
                        <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        


                    </tbody>
                </table>

            </div>


        </div>

    </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/pole/resources/views/campeonatos/calendario.blade.php ENDPATH**/ ?>