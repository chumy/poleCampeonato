<?php $__env->startSection('title', 'Portada'); ?>

<?php $__env->startSection('content'); ?>

<!-- Masthead -->
<header class="masthead text-white text-center escuderia">
    <div class="overlay escuderia"></div>
    <div class="container"></div>
</header>

<section class="campeonatos lista bg-light">

    <div class="container">
        <div class="row">

            <div class="col-lg-4">

                <nav class="navbar navbar-expand-lg navbar-light bg-light">


                <span class="navbar-brand mb-0 h1 d-none d-sm-block"><a href="<?php echo e(route('escuderia.index')); ?>" class="badge badge-light"><h5>Escuderia</h5></a> </span>

                    <div class="navbar" id="navbarSupportedContent">
                        <ul class="navbar-nav mr-auto">


                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <?php echo e($escuderia->nombre); ?>

                                </a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <?php $__currentLoopData = $escuderias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $esc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a class="dropdown-item" href="<?php echo e(route('escuderia.show',['escuderia'=>$esc->id])); ?>"><?php echo e($esc->nombre); ?></a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </div>
                            </li>
                        </ul>
                    </div>


            </div>
        </div>
    </div>




</section>


<section class="secciones-portada bg-light text-center">
    <div class="container">
        <div class="row">
            <div class="col-lg-10">


                <table class="table table-hover table-light">
                    <thead>
                        <tr class="thead-dark">
                            <th scope="col">#</th>
                            <th scope="col">Campeonato</th>
                            <th scope="col">Posicion</th>
                            <th scope="col">Puntos</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $escuderia->puntuacionCampeonatos(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <th scope="row">1</th>
                            <td><a href="<?php echo e(route('campeonato.show',['campeonato'=>$clas->campeonato->id , ])); ?>" class="text-dark"><?php echo e($clas->campeonato->nombre); ?></a></td>
                        <td><?php echo e($clas->posicion); ?></td>
                        <td><?php echo e($clas->puntos_escuderia); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        


                    </tbody>
                </table>

            </div>


        </div>

    </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/pole/resources/views/escuderias/resultado.blade.php ENDPATH**/ ?>