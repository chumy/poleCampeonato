<?php $__env->startSection('title', 'Portada'); ?>

<?php $__env->startSection('content'); ?>

<!-- Masthead -->
<header class="masthead text-white text-center piloto">
    <div class="overlay piloto"></div>
    <div class="container"></div>
</header>

<section class="campeonatos lista">

    <div class="container">
        <div class="row">

           
            <div class="col-sm-3"></div>
            <div class="col-sm-6">

                <div class="card flex-row  card-escuderia">
                    <div class="card-header border-0 card-escuderia-image">
                       <img src="../../../images/lotus.png" alt="" style="height: 200px;">
                    </div>
                    
                    <div class="card-block px-2">
                        <h4 class="card-title"><?php echo e($participante->apodo); ?></h4>
                        
                    </div>
                    
                </div>

            </div>
            <div class="col-sm-3"></div>
        </div> 

        </div>
    </div>




</section>



<section class="secciones-portada  text-center">
    <div class="container">
        <div class="row">
            <div class="col-lg-10">


                <table class="table table-hover ">
                    <thead>
                        <tr class="thead-dark">
                            <th scope="col">#</th>
                            <th scope="col">Campeonato</th>
                            <th scope="col">Posicion</th>
                            <th scope="col">Puntos</th>


                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $participante->puntuacionCampeonatos(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $puntuacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td><a href="<?php echo e(Route ('campeonato.piloto', ['campeonato' => $puntuacion->inscrito->campeonato->slug , 'participante' => $participante->id ])); ?>" class="text-dark"> <?php echo e($puntuacion->inscrito->campeonato->nombre); ?></a>
                            </td>
                            <td><?php echo e($puntuacion->posicion); ?></td>
                        <td><?php echo e($puntuacion->puntos); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                    </tbody>
                </table>

            </div>


        </div>

    </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/pole/resources/views/pilotos/resultado.blade.php ENDPATH**/ ?>