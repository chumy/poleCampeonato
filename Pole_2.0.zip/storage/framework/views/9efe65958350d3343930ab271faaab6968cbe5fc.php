<?php $__env->startSection('title', 'Campeonatos'); ?>

<?php $__env->startSection('content'); ?>


<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-primary">
            <h4 class="card-title ">Listado de Carreras del Campeonato <?php echo e($campeonato->nombre); ?></h4>
                <p class="card-category"> Gestión de todas la carreras disponibles para el campeonato</p>
            </div>
            <div class="card-body">
                <div class="">
                    <table class="table">
                        <thead class=" text-primary">
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Puntuacion</th>
                            <th>Fecha</th>
                            <th></th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $campeonato->carreras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($car->orden); ?></td>
                                <td>
                                    <?php echo e($car->circuito->nombre); ?>

                                </td>
                                <td><?php echo e($car->puntos->nombre); ?> <?php echo e($car->puntos->toText()); ?></td>
                                <td><?php echo e($car->fecha); ?></td>
                                <td>
                                    <div class="row">
                                          <a rel="tooltip" href="<?php echo e(action('CarreraController@edit', $car->id)); ?>" 
                                        title="Editar Carrera"
                                        class="btn btn-primary btn-link btn-sm">
                                        <i class="material-icons">edit</i>
                                </a>
                                    <form
                                        action="<?php echo e(route('carreras.up',  [ 'carrera' =>$car->id  ] )); ?>"
                                        method="post">
                                        <?php echo e(csrf_field()); ?>

                                        <input name="_method" type="hidden" value="PATCH">
                                        <button type="submit" rel="tooltip" title="Subir Posicion"
                                            class="btn btn-primary btn-link btn-sm">
                                            <i class="material-icons">arrow_upward</i>
                                        </button>
                                    </form>

                                    <form
                                        action="<?php echo e(route('carreras.down',  [ 'carrera' =>$car->id  ] )); ?>"
                                        method="post">
                                        <?php echo e(csrf_field()); ?>

                                        <input name="_method" type="hidden" value="PATCH">
                                        <button type="submit" rel="tooltip" title="Bajar Posicion"
                                            class="btn btn-primary btn-link btn-sm">
                                            <i class="material-icons">arrow_downward</i>
                                        </button>
                                    </form>
                                    <form
                                        action="<?php echo e(route('carreras.visible',  [ 'campeonato' =>$car->id  ] )); ?>"
                                        method="post">
                                        <?php echo e(csrf_field()); ?>

                                        <input name="_method" type="hidden" value="PATCH">
                                        <button type="submit" rel="tooltip" title="Cambiar visibilidad Resultados"
                                        class="btn btn-primary btn-link btn-sm">
                                        
                                           <i class="material-icons"><?php echo e(($car->visible) ? 'visibility' : 'visibility_off'); ?></i>
                                           
                                    </button>
                                    </form>

                                    <form action="<?php echo e(action('CarreraController@destroy', $car->id)); ?>" method="post">
                                        <?php echo e(csrf_field()); ?>

                                        <input name="_method" type="hidden" value="DELETE">
                                        <button type="submit" rel="tooltip" title="Eliminar Carrera"
                                            class="btn btn-danger btn-link btn-sm">
                                            <i class="material-icons">close</i>
                                        </button>
                                    </form>
</div>

                                </td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-primary">
            <h4 class="card-title">Agregar Carrera al <?php echo e($campeonato->nombre); ?></h4>
                <p class="card-category">Añadir carreras al campeonato</p>
            </div>
            <div class="card-body">
                <?php if(isset($carrera)): ?>
                    <form method="POST" action="<?php echo e(route('carreras.update',['carrera' => $carrera->id])); ?>" role="form">
                    <input name="_method" type="hidden" value="PATCH">
                <?php else: ?>
                    <form method="POST" action="<?php echo e(route('carreras.store')); ?>" role="form">
                <?php endif; ?>
                        <?php echo e(csrf_field()); ?>


                    <input name="campeonato_id" type="hidden" value="<?php echo e($campeonato->id); ?>">
                    <div class="row">
                        <div class="col-md-5">

                            <div class="form-group">
                                <label for="circuito_id" class="bmd-label-floating">Carrera</label>

                                <select class="form-control" id="circuito_id" name="circuito_id">
                                    <?php $__currentLoopData = $circuitos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cir): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($cir->id); ?>"
                                         <?php if( (isset($carrera)) && ($carrera->circuito->id == $cir->id) ): ?>
                                        selected
                                         <?php endif; ?>
                                        ><?php echo e($cir->nombre); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="punto_id" class="bmd-label-floating">Modelo de Puntuacion</label>
                                <select class="form-control" id="punto_id" name="punto_id">
                                    <?php $__currentLoopData = $puntos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $punto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value=<?php echo e($punto->id); ?>

                                        <?php if( ( (!isset($carrera)) && ($campeonato->punto_id == $punto->id) ) || (isset($carrera) && ($carrera->puntos->id == $punto->id) ) ): ?>
                                         selected
                                         
                                        <?php endif; ?>
                                        ><?php echo e($punto->nombre); ?> - <?php echo e($punto->toText()); ?></option>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="fecha" class="bmd-label-floating">Fecha</label>
                                <input type="text" class="form-control" name="fecha" placeholder="YYYY-MM-DD"
                                 value="<?php echo e((isset($carrera->fecha) ? $carrera->fecha : ''  )); ?>">
                                
                                
       
                            </div>

                        </div>
                    </div>

                    
                    <button type="submit" class="btn btn-primary pull-right"><?php echo e((isset($carrera) ? 'Modificar Carrera': 'Añadir Carrera'  )); ?></button>
                    <div class="clearfix"></div>
                    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <strong>Error!</strong> Revise los campos obligatorios.<br><br>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                    


                </form>
            </div>
        </div>
    </div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/pole/resources/views/admin/carrera.blade.php ENDPATH**/ ?>