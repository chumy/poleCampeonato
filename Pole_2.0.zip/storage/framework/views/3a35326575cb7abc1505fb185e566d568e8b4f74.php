<?php $__env->startSection('title', 'Portada'); ?>



  


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/pole/resources/views/layouts/app.blade.php ENDPATH**/ ?>