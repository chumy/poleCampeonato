<?php $__env->startSection('title', 'Portada'); ?>

<?php $__env->startSection('content'); ?>


<section class="campeonatos lista ">

    <div class="container">
        <div class="row text-center">

            
            <div class="col-sm-2"></div>
            <div class="col-sm-8">

                <div class="card flex-row flex-wrap card-escuderia">
                    <div class="card-header border-0 ">
                       <img class="image-desc img-thumbnail card-escuderia-image" 
                       src="<?php echo e(($escuderia->imagen) ? $escuderia->imagen : asset('images/escuderia_blank.jpg')); ?>" alt="" style="height: 200px;">
                    </div>
                    <div class="card-block px-2">
                        <h4 class="card-title"><?php echo e($escuderia->nombre); ?></h4>
                        <p class="card-text"><?php echo e($escuderia->descripcion); ?></p>
                    </div>
                    <div class="w-100"></div>
                </div>

            </div>
            <div class="col-sm-2"></div>
        </div> 
    </div>




</section>


<section class="secciones-portada text-center">
    <div class="container">
        <div class="row">
            <div class="col-sm-1"></div>
            <div class="col-sm-10">


                <table class="table table-hover">
                    <thead>
                        <tr class="thead-dark">
                            <th scope="col">#</th>
                            <th scope="col">Carrera</th>
                            <th scope="col">Puntos</th>
                            

                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $campeonato->getResultadosEscuderias()->where('escuderia',$escuderia)->sortBy('carrera.orden'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td><?php echo e($car->carrera->circuito->nombre); ?></td>
                            <td><?php echo e($car->puntos); ?></td>
                            
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





                    </tbody>
                </table>


            </div>
<div class="col-sm-1"></div>

        </div>

    </div>
</section>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/pole/resources/views/campeonatos/escuderia.blade.php ENDPATH**/ ?>