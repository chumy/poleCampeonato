<?php $__env->startSection('title', 'Campeonatos'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-primary">
                <h4 class="card-title ">Listado de Campeonatos</h4>
                <p class="card-category"> Gestión de todos los campeonatos disponibles</p>
            </div>
            <div class="card-body">
                <div class="">
                    <table class="table">
                        <thead class=" text-primary">
                            <th>
                                ID
                            </th>
                            <th>
                                Nombre
                            </th>
                            <th>
                            </th>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $campeonatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $camp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($camp->id); ?>

                                </td>
                                <td>
                                    <?php echo e($camp->nombre); ?>

                                </td>

                                <td>
                                    <div class="row">
                                    <a rel="tooltip" href="<?php echo e(action('CampeonatoController@edit', $camp->id)); ?>" 
                                        title="Editar Campeonato"
                                        class="btn btn-primary btn-link btn-sm">
                                        <i class="material-icons">edit</i>
                                    </a>
                                    <a rel="tooltip" title="Administrar Carreras"
                                        class="btn btn-primary btn-link btn-sm"
                                        href="<?php echo e(route('carreras.show', ['campeonato' => $camp->id])); ?>">
                                        <i class="material-icons">location_ons</i>
                                    </a>
                                    <a rel="tooltip" title="Administrar Participantes"
                                        class="btn btn-primary btn-link btn-sm"
                                        href="<?php echo e(route('inscritos.show', ['campeonato' => $camp->id])); ?>">
                                        
                                        <i class="material-icons">person</i>
                                    </a>

                                    <a rel="tooltip" title="Administrar Resultados"
                                        class="btn btn-primary btn-link btn-sm"
                                        href="<?php echo e(route('resultados.show', ['campeonato' => $camp->id])); ?>">
                                        <i class="material-icons">list_alt</i>
                                    </a>

                                    <form
                                        action="<?php echo e(route('campeonatos.visible',  [ 'campeonato' =>$camp->id  ] )); ?>"
                                        method="post">
                                        <?php echo e(csrf_field()); ?>

                                        <input name="_method" type="hidden" value="PATCH">
                                        <button type="submit" rel="tooltip" title="Cambiar visibilidad"
                                        class="btn btn-primary btn-link btn-sm">
                                        
                                           <i class="material-icons"><?php echo e(($camp->visible) ? 'visibility' : 'visibility_off'); ?></i>
                                           
                                    </button>
                                    </form>

                                    <form action="<?php echo e(action('CampeonatoController@destroy', $camp->id)); ?>" method="post">
                                        <?php echo e(csrf_field()); ?>

                                    
                                        <input name="_method" type="hidden" value="DELETE">
                                        <button type="submit" rel="tooltip" title="Eliminar Campeonato"
                                            class="btn btn-danger btn-link btn-sm">
                                            <i class="material-icons">close</i>
                                        </button>
                                    </form>

                                    <a rel="tooltip" title="Pagina Campeonato"
                                        class="btn btn-primary btn-link btn-sm"
                                        href="<?php echo e(route('campeonato.show', ['campeonato' => $camp->slug])); ?>">
                                        <i class="material-icons">open_in_browser</i>
                                    </a>

                                    </div> 
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>



    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-primary">
                <h4 class="card-title">Nuevo Campeonato</h4>
                <p class="card-category">Completa los campos para un nuevo campeonato</p>
            </div>
            <div class="card-body">
                <?php if(isset($campeonato)): ?>
                <form method="POST" action="<?php echo e(route('campeonatos.update',$campeonato->id)); ?>" role="form">

                    <input name="_method" type="hidden" value="PATCH">
                    <?php else: ?>
                    <form method="POST" action="<?php echo e(route('campeonatos.store')); ?>" role="form">
                        <?php endif; ?>

                        <?php echo e(csrf_field()); ?>

                
                    <div class="row">
                        <div class="col-md-5">
                            <div class="form-group">
                                <label class="bmd-label-floating">Nombre</label>
                                <input type="text" name="nombre" class="form-control"
                                value="<?php echo e((isset($campeonato->nombre) ? $campeonato->nombre : ''  )); ?>">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="exampleSelect1" class="bmd-label-floating">Tipo</label>
                                <select class="form-control" id="exampleSelect1" name="tipo">
                                    <option value="1" <?php echo e(( ( isset($campeonato->tipo) && ($campeonato->tipo == 1 ) ) ? 'selected' : ''  )); ?>>Individual</option>
                                    <option value="2" <?php echo e(( ( isset($campeonato->tipo) && ($campeonato->tipo == 2 ) ) ? 'selected' : ''  )); ?>>Escuderias</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label class="bmd-label-floating">Visible</label>
                                <div class="form-check">
                                    <label class="form-check-label">
                                        <input class="form-check-input" type="checkbox" name="visible"
                                                value="<?php echo e((isset($campeonato->visible) ? $campeonato->visible : '0'  )); ?>"
                                                <?php echo e((isset($campeonato->visible) && ($campeonato->visible)) ? 'checked="checked"' : ''); ?>>

                                        <span class="form-check-sign">
                                            <span class="check"></span>
                                        </span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="bmd-label-floating">Numero de coches</label>
                                <input type="text" name="num_coches" class="form-control"
                                value=<?php echo e((isset($campeonato->num_coches) ? $campeonato->num_coches : ''  )); ?>>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="bmd-label-floating">Numero de carreras</label>
                                <input type="text" name="num_carreras"  class="form-control"
                                value=<?php echo e((isset($campeonato->num_carreras) ? $campeonato->num_carreras : ''  )); ?>>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="bmd-label-floating">Numero de vueltas</label>
                                <input type="text" name="num_vueltas" class="form-control"
                                value=<?php echo e((isset($campeonato->num_vueltas) ? $campeonato->num_vueltas : ''  )); ?>>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">

                            <div class="form-group">
                                <label for="exampleSelect2" class="bmd-label-floating">Modelo de Puntuacion por
                                    defecto</label>
                                <select class="form-control" id="exampleSelect2" name="punto_id">
                                    <?php $__currentLoopData = $puntos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $punto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                <option value="<?php echo e($punto->id); ?>"
                                    <?php echo e(( ( isset($campeonato->punto_id) && ($campeonato->punto_id == $punto->id ) ) ? 'selected' : ''  )); ?>

                                    ><?php echo e($punto->nombre); ?> - <?php echo e($punto->toText()); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                        </div>

                        <div class="col-md-2">
                            <div class="form-group">
                                <label class="bmd-label-floating">Expansion Pilotos</label>
                                <div class="form-check">
                                    <label class="form-check-label">
                                        <input class="form-check-input" type="checkbox" name="pilotos"
                                                value="<?php echo e((isset($campeonato->pilotos) ? $campeonato->pilotos : '0'  )); ?>"
                                                <?php echo e((isset($campeonato->pilotos) && ($campeonato->pilotos)) ? 'checked="checked"' : ''); ?>>

                                        <span class="form-check-sign">
                                            <span class="check"></span>
                                        </span>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label class="bmd-label-floating">Expansion Escuderias</label>
                                <div class="form-check">
                                    <label class="form-check-label">
                                        <input class="form-check-input" type="checkbox" name="escuderias"
                                                value="<?php echo e((isset($campeonato->escuderias) ? $campeonato->escuderias : '0'  )); ?>"
                                                <?php echo e((isset($campeonato->escuderias) && ($campeonato->escuderias)) ? 'checked="checked"' : ''); ?>>

                                        <span class="form-check-sign">
                                            <span class="check"></span>
                                        </span>
                                    </label>
                                </div>
                            </div>
                        </div>
                         <div class="col-md-2">

                            <div class="form-group">
                                <label for="puntos_escuderia" class="bmd-label-floating">Puntuacion por Equipos</label>
                                <select class="form-control" id="puntos_escuderia" name="punto_escuderia_id">
                                    <option value="">Ninguna</option>
                                       <?php $__currentLoopData = $puntos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $punto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                <option value="<?php echo e($punto->id); ?>"
                                      <?php echo e(( ( isset($campeonato->punto_escuderia_id) && ($campeonato->punto_escuderia_id == $punto->id ) ) ? 'selected' : ''  )); ?>

                                    ><?php echo e($punto->nombre); ?> - <?php echo e($punto->toText()); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                        </div>
                       
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Descripcion</label>
                                <div class="form-group">
                                    <label class="bmd-label-floating"> Descripcion del Camepeonato.</label>
                                    <textarea class="form-control" rows="5" name="descripcion"><?php echo e((isset($campeonato->descripcion) )  ? $campeonato->descripcion : ''); ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">


                       
                    </div>


                    <button type="submit" class="btn btn-primary pull-right"><?php echo e((isset($campeonato->nombre) ? 'Modificar Campeonato': 'Nuevo Campeonato'  )); ?></button>
                    <div class="clearfix"></div>
                    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <strong>Error!</strong> Revise los campos obligatorios.<br><br>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                </form>
            </div>
        </div>
    </div>
</div>






<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/pole/resources/views/admin/campeonato.blade.php ENDPATH**/ ?>