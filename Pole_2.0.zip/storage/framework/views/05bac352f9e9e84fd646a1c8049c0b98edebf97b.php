<?php $__env->startSection('title', 'Portada'); ?>

<?php $__env->startSection('content'); ?>

<!-- Masthead -->
<header class="masthead text-white text-center pilotos">
    <div class="overlay pilotos"></div>
    <div class="container"></div>
</header>




<section class="secciones-portada  text-center">
    <div class="container">
        <div class="row">
            <div class="col-sm-1"></div>
            <div class="col-lg-10">


                <table class="table table-hover">
                    <thead>
                        <tr class="thead-dark">
                            <th scope="col">#</th>
                            <th scope="col">Piloto</th>

                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pilotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $piloto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td><?php echo e($piloto->apodo); ?></td>

                            <td><a 
                                  href="<?php echo e(route('campeonato.piloto', [ 'campeonato' =>$campeonato->slug ,'participante' => $piloto->id])); ?>"><i
                                      ><i
                                        class="material-icons">timer</i></a></td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>
                </table>


            </div>


        </div>
        <div class="col-sm-1"></div>

    </div>
</section>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/pole/resources/views/pilotos/pilotos.blade.php ENDPATH**/ ?>